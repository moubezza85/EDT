import json
import os
import threading
from typing import Dict, Any, Tuple

class TimetableRepo:
    def __init__(self, data_dir: str):
        self.path = os.path.join(data_dir, "timetable.json")
        self._lock = threading.Lock()

    def read(self) -> Dict[str, Any]:
        with open(self.path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            # compat legacy: liste simple -> on enveloppe
            return {"version": 1, "sessions": data}
        if "version" not in data:
            data["version"] = 1
        if "sessions" not in data:
            data["sessions"] = []
        return data

    def write(self, data: Dict[str, Any]) -> None:
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def atomic_update(self, fn) -> Tuple[bool, Dict[str, Any], Dict[str, Any]]:
        """
        Exécute fn(current_data) sous verrou.
        Retour:
          ok, new_data, error_payload
        """
        with self._lock:
            current = self.read()
            return fn(current)
