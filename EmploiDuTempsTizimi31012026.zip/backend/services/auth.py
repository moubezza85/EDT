import json
import os
from typing import Any, Dict, Optional


def load_users(data_dir: str, filename: str = "users.json") -> Dict[str, Any]:
    """Load users.json from data_dir.

    Supported formats:
      - {"users": [...]} (recommended)
      - [...] (legacy)  -> treated as users list
    """
    path = os.path.join(data_dir, filename)
    if not os.path.exists(path):
        return {"users": []}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return {"users": data}
    if not isinstance(data, dict):
        return {"users": []}
    data.setdefault("users", [])
    if not isinstance(data["users"], list):
        data["users"] = []
    return data


def find_user(data_dir: str, user_id: str) -> Optional[Dict[str, Any]]:
    if not user_id:
        return None
    users = load_users(data_dir).get("users", []) or []
    for u in users:
        if str((u or {}).get("id", "")).strip() == str(user_id).strip():
            # normalize
            out = dict(u)
            out["id"] = str(out.get("id", "")).strip()
            out["name"] = str(out.get("name", out.get("id", ""))).strip()
            out["role"] = str(out.get("role", "")).strip().lower() or "formateur"
            return out
    return None
