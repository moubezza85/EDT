// src/api/roomsApi.ts
import { httpOk } from "./http";

export type AvailableRoomsResponse = {
  ok: true;
  availableRooms: string[];
  occupiedRooms?: string[];
};

export function getAvailableRooms(jour: string, creneau: number) {
  const qs = new URLSearchParams({ jour, creneau: String(creneau) }).toString();
  return httpOk<AvailableRoomsResponse>(`/api/rooms/available?${qs}`, { method: "GET" });
}
