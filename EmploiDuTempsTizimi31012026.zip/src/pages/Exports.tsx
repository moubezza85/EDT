// src/pages/Exports.tsx
import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";

import { getCatalog, type Catalog } from "@/api/catalogApi";
import { getConfig, type Config } from "@/api/configApi";

const API_BASE_URL = import.meta.env.VITE_API_BASE;

export default function Exports() {
  const { toast } = useToast();

  // data
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [cfg, setCfg] = useState<Config | null>(null);

  // selections
  const [trainerId, setTrainerId] = useState("");
  const [groupe, setGroupe] = useState("");
  const [salle, setSalle] = useState("");

  useEffect(() => {
    getCatalog().then(setCatalog);
    getConfig().then(setCfg);
  }, []);

  const trainers = useMemo(() => catalog?.teachers ?? [], [catalog]);

  // IMPORTANT:
  // On utilise UNIQUEMENT les groupes "réels" du catalog => pas de fusions.
  const groupes = useMemo(() => catalog?.groups ?? [], [catalog]);

  const salles = useMemo(() => cfg?.salles ?? [], [cfg]);

  const openAndToast = (url: string, message: string) => {
    toast({ title: message });
    window.open(url, "_blank", "noopener,noreferrer");
  };

  return (
    <div className="container mx-auto py-6 px-4 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Exports PDF – Emploi du temps</h1>
        <p className="text-gray-500">Télécharger les emplois du temps (semaine courante)</p>
      </div>

      {/* -------- Formateur -------- */}
      <Card>
        <CardHeader>
          <CardTitle>Export par Formateur</CardTitle>
        </CardHeader>
        <CardContent className="flex gap-4 items-end">
          <Select value={trainerId} onValueChange={setTrainerId}>
            <SelectTrigger className="w-[300px]">
              <SelectValue placeholder="Choisir un formateur" />
            </SelectTrigger>
            <SelectContent>
              {trainers.map((t) => (
                <SelectItem key={t.id} value={t.id}>
                  {t.name} ({t.id})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            disabled={!trainerId}
            onClick={() =>
              openAndToast(
                `${API_BASE_URL}/api/reports/timetable/formateur/${encodeURIComponent(trainerId)}`,
                "Génération du PDF formateur."
              )
            }
          >
            Télécharger PDF
          </Button>
        </CardContent>
      </Card>

      {/* -------- Groupe -------- */}
      <Card>
        <CardHeader>
          <CardTitle>Export par Groupe</CardTitle>
        </CardHeader>
        <CardContent className="flex gap-4 items-end">
          <Select value={groupe} onValueChange={setGroupe}>
            <SelectTrigger className="w-[300px]">
              <SelectValue placeholder="Choisir un groupe" />
            </SelectTrigger>
            <SelectContent>
              {groupes.map((g) => (
                <SelectItem key={g} value={g}>
                  {g}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            disabled={!groupe}
            onClick={() =>
              openAndToast(
                `${API_BASE_URL}/api/reports/timetable/groupe/${encodeURIComponent(groupe)}`,
                "Génération du PDF groupe."
              )
            }
          >
            Télécharger PDF
          </Button>
        </CardContent>
      </Card>

      {/* -------- Salle -------- */}
      <Card>
        <CardHeader>
          <CardTitle>Export par Salle</CardTitle>
        </CardHeader>
        <CardContent className="flex gap-4 items-end">
          <Select value={salle} onValueChange={setSalle}>
            <SelectTrigger className="w-[300px]">
              <SelectValue placeholder="Choisir une salle" />
            </SelectTrigger>
            <SelectContent>
              {salles.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  {s.id} {s.type ? `(${s.type})` : ""}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            disabled={!salle}
            onClick={() =>
              openAndToast(
                `${API_BASE_URL}/api/reports/timetable/salle/${encodeURIComponent(salle)}`,
                "Génération du PDF salle."
              )
            }
          >
            Télécharger PDF
          </Button>
        </CardContent>
      </Card>

      {/* -------- ZIP GLOBAL -------- */}
      <Card className="border-2 border-black">
        <CardHeader>
          <CardTitle>Export global</CardTitle>
        </CardHeader>
        <CardContent>
          <Button
            className="w-full"
            onClick={() =>
              openAndToast(
                `${API_BASE_URL}/api/reports/timetable/all`,
                "Génération du ZIP complet."
              )
            }
          >
            Télécharger ZIP complet (Formateurs + Groupes + Salles)
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
