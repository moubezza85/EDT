import { createBrowserRouter } from "react-router-dom";
import AppLayout from "./AppLayout";

import Index from "@/pages/Index";
import Settings from "@/pages/Settings";
import GenerateTimetable from "@/pages/GenerateTimeTable";
import FreeRooms from "@/pages/FreeRooms";
import Dashboard from "@/pages/Dashboard";
import Exports from "@/pages/Exports";
import VirtualTimetable from "@/pages/VirtualTimetable";
import PendingRequests from "@/pages/PendingRequests";


export const router = createBrowserRouter([
  {
    element: <AppLayout />,
    children: [
      { path: "/", element: <Index /> },
      { path: "/parametres", element: <Settings /> },
      { path: "/genereremploi", element: <GenerateTimetable /> },
      { path: "/sallelibre", element: <FreeRooms /> },
      { path: "/dashboard", element: <Dashboard /> },
      { path: "/exports",  element: <Exports /> },
      { path: "/virtuel",  element: <VirtualTimetable /> },
      { path: "/pending",  element: <PendingRequests /> },
      { path: "/exports",  element: <Exports /> },
    ],
  },
]);
