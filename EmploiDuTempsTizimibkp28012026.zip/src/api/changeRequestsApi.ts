// src/api/changeRequestsApi.ts
import type { ChangeRequest } from "@/types/changeRequests";

const API_BASE = (import.meta.env.VITE_API_BASE as string | undefined) ?? "";

async function safeJson(res: Response) {
  const text = await res.text();
  try {
    return text ? JSON.parse(text) : {};
  } catch {
    return { raw: text };
  }
}

export async function listAdminChanges(status: string = "PENDING"): Promise<ChangeRequest[]> {
  const res = await fetch(`${API_BASE}/api/admin/changes?status=${encodeURIComponent(status)}`);
  const json = await safeJson(res);
  if (!res.ok) throw new Error(json?.message ?? json?.error ?? "Impossible de charger les demandes");
  return (json?.requests ?? []) as ChangeRequest[];
}

export async function simulateAdminChange(requestId: string, decidedBy: string = "ADMIN") {
  const res = await fetch(`${API_BASE}/api/admin/changes/${encodeURIComponent(requestId)}/simulate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ decidedBy }),
  });
  const json = await safeJson(res);
  if (!res.ok) throw new Error(json?.message ?? json?.error ?? "Simulation impossible");
  return json;
}

export async function approveAdminChange(requestId: string, decidedBy: string = "ADMIN") {
  const res = await fetch(`${API_BASE}/api/admin/changes/${encodeURIComponent(requestId)}/approve`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ decidedBy }),
  });
  const json = await safeJson(res);
  if (!res.ok) throw new Error(json?.message ?? json?.error ?? "Approbation impossible");
  return json;
}

export async function rejectAdminChange(requestId: string, reason: string, decidedBy: string = "ADMIN") {
  const res = await fetch(`${API_BASE}/api/admin/changes/${encodeURIComponent(requestId)}/reject`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ decidedBy, reason }),
  });
  const json = await safeJson(res);
  if (!res.ok) throw new Error(json?.message ?? json?.error ?? "Rejet impossible");
  return json;
}
