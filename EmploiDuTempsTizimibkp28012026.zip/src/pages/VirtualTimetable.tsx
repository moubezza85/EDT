// src/pages/VirtualTimetable.tsx
import { useCallback, useEffect, useMemo, useState } from "react";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";

import VirtualScheduleGrid from "@/components/VirtualScheduleGrid";
import FilterBar from "../components/FilterBar";
import AddSessionModal from "../components/AddSessionModal";

import { useSchedule } from "../hooks/useSchedule";
import { FilterType, type Session } from "../types";
import { useToast } from "../components/ui/use-toast";

import { getConfig, type Config } from "../api/configApi";
import { getCatalog, type Catalog } from "../api/catalogApi";
import { addSession } from "../api/timetableApi";

import { listAdminChanges } from "@/api/changeRequestsApi";
import type { ChangeRequest } from "@/types/changeRequests";

const ALL = "_all";

export default function VirtualTimetable() {
  const { toast } = useToast();

  // ---- config ----
  const [cfg, setCfg] = useState<Config | null>(null);
  const [cfgLoading, setCfgLoading] = useState(false);
  const [cfgError, setCfgError] = useState<string | null>(null);

  // ---- catalog ----
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [catalogLoading, setCatalogLoading] = useState(false);
  const [catalogError, setCatalogError] = useState<string | null>(null);

  // ---- add modal ----
  const [addOpen, setAddOpen] = useState(false);

  // ---- pending requests ----
  const [pending, setPending] = useState<ChangeRequest[]>([]);
  const [pendingLoading, setPendingLoading] = useState(false);

  // -------- helpers: virtual rooms + fusions --------
  const isVirtualRoom = useCallback(
    (roomId: string) => {
      const salles = cfg?.salles ?? [];
      const found = salles.find((s: any) => (typeof s === "string" ? s === roomId : s?.id === roomId));
      const type = typeof found === "string" ? null : found?.type;
      return (type ?? "").toUpperCase() === "VIRTUEL";
    },
    [cfg]
  );

  // FIX: OnlineFusion a "groupes" (pas "groups")
  const fusionMap = useMemo(() => {
    const m = new Map<string, string[]>();
    (catalog?.onlineFusions ?? []).forEach((f: any) => m.set(f.id, f.groupes ?? []));
    return m;
  }, [catalog]);

  const expandGroupIds = useCallback(
    (groupeId: string) => {
      const kids = fusionMap.get(groupeId);
      return kids?.length ? kids : [groupeId];
    },
    [fusionMap]
  );

  const formatGroupLabel = useCallback(
    (groupeId: string) => {
      const kids = fusionMap.get(groupeId);
      return kids?.length ? `${groupeId}` : groupeId;
    },
    [fusionMap]
  );

  const {
    sessions,
    loading,
    error,
    hasConflict,
    updateSession,
    fetchData,
    uniqueFormateurValues,
    uniqueGroupeValues,
    uniqueSalleValues,
    filters,
    addFilter,
    removeFilter,
    deleteSession,
  } = useSchedule({ expandGroupIds, isVirtualRoom });

  // ---- rooms for grid (salles physiques uniquement) ----
  const salleIdsPhysical = useMemo(() => {
    const raw = cfg?.salles ?? [];
    const ids = raw
      .map((s: any) => (typeof s === "string" ? s : s?.id))
      .filter((x: any): x is string => typeof x === "string" && x.trim().length > 0);

    return ids.filter((id) => !isVirtualRoom(id));
  }, [cfg, isVirtualRoom]);

  // ---- filter options (UI) ----
  const groupeOptions = useMemo(() => {
    // selon vos fichiers, ça peut être "groups" (catalog) ; on garde un fallback safe
    const fromCatalog = (((catalog as any)?.groups ?? []) as string[]).filter((g) => (g ?? "").trim().length > 0);
    return fromCatalog.length ? fromCatalog : uniqueGroupeValues;
  }, [catalog, uniqueGroupeValues]);

  const salleOptions = useMemo(
    () => uniqueSalleValues.filter((id) => !isVirtualRoom(id)),
    [uniqueSalleValues, isVirtualRoom]
  );

  // ---- FIX FilterBar : attendre Record<string,string> + addFilter({type,value}) ----
  const filtersRecord = useMemo(() => {
    const rec: Record<string, string> = {
      formateur: ALL,
      groupe: ALL,
      salle: ALL,
    };
    (filters ?? []).forEach((f: any) => {
      rec[f.type] = f.value;
    });
    return rec;
  }, [filters]);

  const handleFilterChange = useCallback(
    (type: FilterType, value: string) => {
      addFilter({ type, value });
    },
    [addFilter]
  );

  const handleClearFilter = useCallback(
    (type: FilterType) => {
      removeFilter(type);
    },
    [removeFilter]
  );

  // ---- load config + catalog ----
  useEffect(() => {
    (async () => {
      try {
        setCfgLoading(true);
        setCfgError(null);
        const c = await getConfig();
        setCfg(c);
      } catch (e: any) {
        setCfgError(e?.message ?? "Erreur config");
      } finally {
        setCfgLoading(false);
      }
    })();

    (async () => {
      try {
        setCatalogLoading(true);
        setCatalogError(null);
        const cat = await getCatalog();
        setCatalog(cat);
      } catch (e: any) {
        setCatalogError(e?.message ?? "Erreur catalog");
      } finally {
        setCatalogLoading(false);
      }
    })();
  }, []);

  // ---- load pending requests ----
  const refreshPending = useCallback(async () => {
    try {
      setPendingLoading(true);
      const list = await listAdminChanges("PENDING");
      setPending(list);
    } catch (e: any) {
      toast({
        variant: "destructive",
        title: "Erreur demandes",
        description: e?.message ?? "Impossible de charger les PENDING",
      });
    } finally {
      setPendingLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    refreshPending();
  }, [refreshPending]);

  // ---- build overlay structures ----
  const movedSessionIds = useMemo(() => {
    const s = new Set<string>();
    pending.forEach((r) => s.add(String(r.sessionId)));
    return s;
  }, [pending]);

  const ghostSessions = useMemo(() => {
    // index rapide des sessions réelles par id
    const byId = new Map<string, Session>();
    sessions.forEach((s) => byId.set(String(s.id), s));

    // index occupation réelle par cellule
    const occ = new Map<string, string[]>(); // key => [sessionId...]
    const key = (jour: string, c: number, salle: string) => `${jour}::${c}::${salle}`;
    sessions.forEach((s) => {
      const k = key(String(s.jour), Number(s.creneau), String(s.salle));
      const arr = occ.get(k) ?? [];
      arr.push(String(s.id));
      occ.set(k, arr);
    });

    return pending.map((r) => {
      const original = byId.get(String(r.sessionId));
      const j = String(r.newData.jour);
      const c = Number(r.newData.creneau);
      const salle = String(r.newData.salle ?? "");

      const k = key(j, c, salle);
      const collisions = (occ.get(k) ?? []).filter((sid) => sid !== String(r.sessionId));
      const hasCollision = collisions.length > 0;

      return {
        id: `ghost:${r.id}`,
        requestId: r.id,
        originalSessionId: String(r.sessionId),
        jour: j,
        creneau: c,
        salle,
        module: original?.module,
        groupe: original?.groupe,
        formateur: original?.formateur,
        motif: r.newData.motif ?? null,
        hasCollision,
      };
    });
  }, [pending, sessions]);

  // ---- handlers ----
  const handleRefresh = useCallback(async () => {
    await fetchData();
    await refreshPending();
  }, [fetchData, refreshPending]);

  const handleAdd = useCallback(
    async (data: any) => {
      try {
        await addSession(data);
        toast({ title: "Séance ajoutée", description: "Séance ajoutée au planning officiel." });
        await fetchData();
      } catch (e: any) {
        toast({ variant: "destructive", title: "Erreur ajout", description: e?.message ?? "Impossible d'ajouter" });
      }
    },
    [fetchData, toast]
  );

  if (cfgLoading || catalogLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (cfgError || catalogError) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="bg-red-50 text-red-700 p-4 rounded">
          {cfgError ? `Config: ${cfgError}` : null}
          {catalogError ? `Catalog: ${catalogError}` : null}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b p-4 shadow-sm">
        <h1 className="text-2xl font-bold">Emploi du temps — Vue négociation</h1>
        <p className="text-gray-500">
          Planning officiel + calque “propositions” (PENDING). Interactions admin inchangées (DnD / ajout / suppression).
        </p>
      </header>

      <main className="container mx-auto py-6 px-4">
        <div className="mb-4">
          <FilterBar
            formateurOptions={uniqueFormateurValues}
            groupeOptions={groupeOptions}
            salleOptions={salleOptions}
            onFilterChange={handleFilterChange}
            onClearFilter={handleClearFilter}
            onRefresh={handleRefresh}
            filters={filtersRecord}
            isLoading={loading || pendingLoading}
          />
        </div>

        <div className="mb-4 flex items-center justify-between">
          <button
            className="rounded border border-black bg-white px-3 py-2 text-black"
            onClick={() => setAddOpen(true)}
          >
            + Ajouter une séance
          </button>

          <div className="text-sm text-gray-600">
            PENDING: <span className="font-semibold">{pending.length}</span>{" "}
            {pendingLoading ? <span className="text-gray-400">(chargement...)</span> : null}
          </div>
        </div>

        {error ? <div className="bg-red-50 text-red-700 p-4 rounded-md my-4">{String(error)}</div> : null}

        <div className="bg-white rounded-md shadow-sm">
          <DndProvider backend={HTML5Backend}>
            <VirtualScheduleGrid
              sessions={sessions}
              ghostSessions={ghostSessions}
              movedSessionIds={movedSessionIds}
              hasConflict={hasConflict}
              updateSession={updateSession}
              rooms={salleIdsPhysical}
              isLoading={loading}
              onDeleteSession={deleteSession}
              formatGroupLabel={formatGroupLabel}
            />
          </DndProvider>
        </div>

        {cfg && catalog ? (
          <AddSessionModal
            open={addOpen}
            onClose={() => setAddOpen(false)}
            jours={cfg.jours}
            creneaux={cfg.creneaux}
            salles={salleIdsPhysical}
            catalog={catalog}
            onSubmit={handleAdd}
          />
        ) : null}
      </main>
    </div>
  );
}
