from typing import Dict, Any, List, Optional

def _sid(s: Dict[str, Any]) -> str:
    return s.get("id") or s.get("sessionId")

def validate_move(sessions: List[Dict[str, Any]], session_id: str, to_jour: str, to_creneau: int, to_salle: str) -> Optional[Dict[str, Any]]:
    target = next((s for s in sessions if _sid(s) == session_id), None)
    if not target:
        return {"code": "NOT_FOUND", "message": "Session introuvable"}

    for s in sessions:
        if _sid(s) == session_id:
            continue
        if s.get("jour") != to_jour or int(s.get("creneau")) != int(to_creneau):
            continue

        if s.get("salle") == to_salle:
            return {"code": "CONSTRAINT_CONFLICT", "message": "Conflit: salle déjà occupée sur ce créneau", "details": {"conflictingSessionId": _sid(s)}}
        if s.get("formateur") == target.get("formateur"):
            return {"code": "CONSTRAINT_CONFLICT", "message": "Conflit: formateur déjà occupé sur ce créneau", "details": {"conflictingSessionId": _sid(s)}}
        if s.get("groupe") == target.get("groupe"):
            return {"code": "CONSTRAINT_CONFLICT", "message": "Conflit: groupe déjà occupé sur ce créneau", "details": {"conflictingSessionId": _sid(s)}}

    return None

def apply_move(sessions: List[Dict[str, Any]], session_id: str, to_jour: str, to_creneau: int, to_salle: str) -> List[Dict[str, Any]]:
    out = []
    for s in sessions:
        if _sid(s) == session_id:
            ns = dict(s)
            ns["jour"] = to_jour
            ns["creneau"] = int(to_creneau)
            ns["salle"] = to_salle
            # normaliser id
            if "id" not in ns and ns.get("sessionId"):
                ns["id"] = ns["sessionId"]
            out.append(ns)
        else:
            out.append(s)
    return out

def validate_delete(sessions: List[Dict[str, Any]], session_id: str) -> Optional[Dict[str, Any]]:
    target = next((s for s in sessions if _sid(s) == session_id), None)
    if not target:
        return {"code": "NOT_FOUND", "message": "Session introuvable"}
    return None

def apply_delete(sessions: List[Dict[str, Any]], session_id: str) -> List[Dict[str, Any]]:
    return [s for s in sessions if _sid(s) != session_id]

