# routes/requests_routes.py
from flask import Blueprint, jsonify, request
from typing import Any, Dict, List, Optional, Tuple

from services.change_requests_store import ChangeRequestsStore
from services.timetable_repo import TimetableRepo
from services.timetable_rules import validate_move, apply_move


def _bad_request(message: str, code: str = "BAD_REQUEST"):
    return jsonify({"ok": False, "code": code, "message": message}), 400


def _conflict(message: str, code: str = "CONSTRAINT_CONFLICT", details: Optional[Dict[str, Any]] = None):
    payload = {"ok": False, "code": code, "message": message}
    if details:
        payload["details"] = details
    return jsonify(payload), 409


def _sid(s: Dict[str, Any]) -> str:
    return s.get("id") or s.get("sessionId")


def _normalize_sessions(sessions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    for s in sessions:
        out.append({
            "id": s.get("id") or s.get("sessionId"),
            "formateur": s.get("formateur"),
            "groupe": s.get("groupe"),
            "module": s.get("module"),
            "jour": s.get("jour"),
            "creneau": s.get("creneau"),
            "salle": s.get("salle"),
        })
    return out


def _get_session_or_none(sessions: List[Dict[str, Any]], session_id: str) -> Optional[Dict[str, Any]]:
    for s in sessions:
        if _sid(s) == session_id:
            return s
    return None


def _build_virtual_view(
    base_sessions: List[Dict[str, Any]],
    pending_requests: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Vue virtuelle simple (overlay) :
    - sessions_base: chaque session a un champ _virtualState: NORMAL | MOVED_AWAY | TO_DELETE
    - sessions_extra: les destinations proposées (_virtualState = PROPOSED_DESTINATION)
    """
    # Index request MOVE/CHANGE_ROOM par sessionId (PENDING)
    by_session: Dict[str, Dict[str, Any]] = {}
    for r in pending_requests:
        sid = str(r.get("sessionId", "")).strip()
        if not sid:
            continue
        by_session[sid] = r

    sessions_base = []
    sessions_extra = []

    for s in base_sessions:
        sid = _sid(s)
        req = by_session.get(str(sid))
        if not req:
            ss = dict(s)
            ss["_virtualState"] = "NORMAL"
            sessions_base.append(ss)
            continue

        rtype = str(req.get("type", "")).upper()
        if rtype in ("MOVE", "CHANGE_ROOM"):
            # ancienne position affichée comme "moved away"
            ss = dict(s)
            ss["_virtualState"] = "MOVED_AWAY"
            ss["_virtualRequestId"] = req.get("id")
            sessions_base.append(ss)

            # destination proposée
            nd = req.get("newData") or {}
            dest = dict(s)
            dest["jour"] = nd.get("jour", s.get("jour"))
            dest["creneau"] = nd.get("creneau", s.get("creneau"))
            dest["salle"] = nd.get("salle", s.get("salle"))
            dest["_virtualState"] = "PROPOSED_DESTINATION"
            dest["_virtualRequestId"] = req.get("id")
            sessions_extra.append(dest)
        else:
            # type inconnu => laisser normal
            ss = dict(s)
            ss["_virtualState"] = "NORMAL"
            sessions_base.append(ss)

    return {
        "sessionsBase": _normalize_sessions(sessions_base),
        "sessionsExtra": _normalize_sessions(sessions_extra),
        "raw": {
            # pour debug éventuel: états virtuels
            "sessionsBase": sessions_base,
            "sessionsExtra": sessions_extra,
        }
    }


def create_requests_blueprint(data_dir: str) -> Blueprint:
    """
    Factory: on injecte DATA_DIR depuis app.py
    """
    requests_bp = Blueprint("requests_bp", __name__)

    store = ChangeRequestsStore(data_dir)
    repo = TimetableRepo(data_dir)

    # ----------------------------
    # TEACHER
    # ----------------------------

    @requests_bp.route("/api/teacher/timetable", methods=["GET"])
    def teacher_timetable():
        teacher_id = request.args.get("teacherId")
        if not teacher_id:
            return _bad_request("teacherId requis")

        data = repo.read()
        sessions = data.get("sessions", []) or []
        # Filtrer seulement les séances du formateur
        filtered = [s for s in sessions if str(s.get("formateur", "")).strip() == str(teacher_id).strip()]

        # Overlay des demandes PENDING de ce teacher (optionnel mais utile)
        pending = store.list(status="PENDING", teacher_id=str(teacher_id).strip())
        vv = _build_virtual_view(filtered, pending)

        return jsonify({
            "ok": True,
            "version": data.get("version", 1),
            "sessions": _normalize_sessions(filtered),
            "virtual": {
                "sessionsBase": vv["sessionsBase"],
                "sessionsExtra": vv["sessionsExtra"],
            },
            "pendingRequests": pending,
        })

    @requests_bp.route("/api/teacher/changes", methods=["GET"])
    def teacher_list_changes():
        teacher_id = request.args.get("teacherId")
        status = request.args.get("status")  # optional
        if not teacher_id:
            return _bad_request("teacherId requis")

        items = store.list(status=status, teacher_id=str(teacher_id).strip())
        return jsonify({"ok": True, "requests": items})

    @requests_bp.route("/api/teacher/changes", methods=["POST"])
    def teacher_create_change():
        body = request.get_json(force=True) or {}

        teacher_id = body.get("teacherId")
        session_id = body.get("sessionId")
        req_type = (body.get("type") or "MOVE").upper()
        new_data = body.get("newData") or {}

        if not teacher_id or not session_id:
            return _bad_request("teacherId et sessionId requis")

        # Charger la session officielle pour oldData
        data = repo.read()
        sessions = data.get("sessions", []) or []
        target = _get_session_or_none(sessions, str(session_id))
        if not target:
            return _bad_request("Session introuvable", code="NOT_FOUND")

        # Sécurité métier: teacher ne peut proposer que ses séances
        if str(target.get("formateur", "")).strip() != str(teacher_id).strip():
            return _bad_request("Vous ne pouvez proposer que sur vos propres séances", code="FORBIDDEN")

        # Construire oldData / newData (normalisés)
        old_data = {
            "jour": target.get("jour"),
            "creneau": int(target.get("creneau")),
            "salle": target.get("salle"),
        }

        # Pour MOVE: jour/creneau/salle sont attendus
        # Pour CHANGE_ROOM: vous pouvez n’envoyer que salle, mais on garde jour/creneau d’origine
        if req_type == "CHANGE_ROOM":
            if not new_data.get("salle"):
                return _bad_request("newData.salle requis pour CHANGE_ROOM")
            new_data = {
                "jour": old_data["jour"],
                "creneau": old_data["creneau"],
                "salle": new_data.get("salle"),
                "motif": new_data.get("motif"),
            }
        else:
            # MOVE
            if not new_data.get("jour") or new_data.get("creneau") is None or not new_data.get("salle"):
                return _bad_request("newData.jour, newData.creneau, newData.salle requis pour MOVE")

            new_data = {
                "jour": str(new_data.get("jour")).strip().lower(),
                "creneau": int(new_data.get("creneau")),
                "salle": str(new_data.get("salle")).strip(),
                "motif": new_data.get("motif"),
            }

        # IMPORTANT: vous avez dit que la validation est déjà côté backend au moment d'appliquer.
        # Donc ici, on stocke juste (dernière proposition gagne).
        created = store.upsert_pending_for_session(
            teacher_id=str(teacher_id).strip(),
            session_id=str(session_id).strip(),
            req_type=req_type,
            old_data=old_data,
            new_data=new_data,
            supersede_previous=True,  # garde l’audit
        )
        return jsonify({"ok": True, "request": created})

    # ----------------------------
    # ADMIN / DIRECTEUR
    # ----------------------------

    @requests_bp.route("/api/admin/changes", methods=["GET"])
    def admin_list_changes():
        status = request.args.get("status")  # PENDING by default
        teacher_id = request.args.get("teacherId")
        session_id = request.args.get("sessionId")

        if not status:
            status = "PENDING"

        items = store.list(
            status=status,
            teacher_id=teacher_id.strip() if teacher_id else None,
            session_id=session_id.strip() if session_id else None,
        )
        return jsonify({"ok": True, "requests": items})

    @requests_bp.route("/api/admin/timetable/virtual", methods=["GET"])
    def admin_virtual_timetable():
        data = repo.read()
        sessions = data.get("sessions", []) or []
        pending = store.list(status="PENDING")

        vv = _build_virtual_view(sessions, pending)
        return jsonify({
            "ok": True,
            "version": data.get("version", 1),
            "sessions": _normalize_sessions(sessions),  # officiel
            "virtual": {
                "sessionsBase": vv["sessionsBase"],
                "sessionsExtra": vv["sessionsExtra"],
            },
            "pendingRequests": pending,
        })

    def _validate_and_apply_request(current: Dict[str, Any], req: Dict[str, Any]) -> Tuple[bool, Dict[str, Any]]:
        """
        Réutilise vos règles existantes:
        - validate_move / apply_move
        Puis commit via TimetableRepo.atomic_update (au niveau route approve/simulate)
        """
        sessions = current.get("sessions", []) or []
        session_id = str(req.get("sessionId"))

        nd = req.get("newData") or {}
        to_jour = str(nd.get("jour", "")).strip().lower()
        to_creneau = nd.get("creneau", None)
        to_salle = str(nd.get("salle", "")).strip()

        if not session_id or not to_jour or to_creneau is None or not to_salle:
            return (False, {"ok": False, "code": "BAD_REQUEST", "message": "Demande invalide (newData incomplet)"})

        # validation (conflits)
        err = validate_move(sessions, session_id, to_jour, int(to_creneau), to_salle)
        if err:
            err["ok"] = False
            return (False, err)

        # apply
        new_sessions = apply_move(sessions, session_id, to_jour, int(to_creneau), to_salle)
        new_data = {
            "version": int(current.get("version", 1)) + 1,
            "sessions": new_sessions
        }
        return (True, new_data)

    @requests_bp.route("/api/admin/changes/<request_id>/simulate", methods=["POST"])
    def admin_simulate_change(request_id: str):
        # (optionnel mais utile pour l’UX admin)
        req = store.get(request_id)
        if not req:
            return _bad_request("Demande introuvable", code="NOT_FOUND")
        if str(req.get("status")) != "PENDING":
            return _bad_request("Seules les demandes PENDING peuvent être simulées", code="INVALID_STATUS")

        current = repo.read()
        ok, data_or_err = _validate_and_apply_request(current, req)
        if not ok:
            # conflit / invalid => 409
            return _conflict(data_or_err.get("message", "Conflit"), code=data_or_err.get("code", "CONSTRAINT_CONFLICT"), details=data_or_err.get("details"))

        # OK: renvoyer uniquement un aperçu léger
        return jsonify({
            "ok": True,
            "message": "Simulation OK",
            "newVersionWouldBe": data_or_err.get("version"),
        })

    @requests_bp.route("/api/admin/changes/<request_id>/approve", methods=["POST"])
    def admin_approve_change(request_id: str):
        body = request.get_json(force=True) or {}
        decided_by = body.get("decidedBy") or "ADMIN"

        req = store.get(request_id)
        if not req:
            return _bad_request("Demande introuvable", code="NOT_FOUND")
        if str(req.get("status")) != "PENDING":
            return _bad_request("Seules les demandes PENDING peuvent être approuvées", code="INVALID_STATUS")

        def do_update(current: Dict[str, Any]):
            ok, data_or_err = _validate_and_apply_request(current, req)
            if not ok:
                # retour pour route
                return (False, current, data_or_err)
            # commit
            repo.write(data_or_err)
            return (True, data_or_err, {})

        ok, new_data, err_payload = repo.atomic_update(do_update)

        if not ok:
            # marquer REJECTED avec raison (le planning a changé / conflit apparu)
            msg = err_payload.get("message", "Conflit lors de l'approbation")
            store.set_status(request_id, status="REJECTED", decided_by=str(decided_by), reason=msg)
            return _conflict(msg, code=err_payload.get("code", "CONSTRAINT_CONFLICT"), details=err_payload.get("details"))

        store.set_status(request_id, status="APPROVED", decided_by=str(decided_by), reason=None)
        return jsonify({
            "ok": True,
            "message": "Demande approuvée et appliquée",
            "version": new_data.get("version"),
            "sessions": _normalize_sessions(new_data.get("sessions", []) or []),
        })

    @requests_bp.route("/api/admin/changes/<request_id>/reject", methods=["POST"])
    def admin_reject_change(request_id: str):
        body = request.get_json(force=True) or {}
        decided_by = body.get("decidedBy") or "ADMIN"
        reason = body.get("reason") or "Rejected by admin"

        req = store.get(request_id)
        if not req:
            return _bad_request("Demande introuvable", code="NOT_FOUND")
        if str(req.get("status")) != "PENDING":
            return _bad_request("Seules les demandes PENDING peuvent être rejetées", code="INVALID_STATUS")

        updated = store.set_status(request_id, status="REJECTED", decided_by=str(decided_by), reason=str(reason))
        return jsonify({"ok": True, "request": updated})

    return requests_bp
