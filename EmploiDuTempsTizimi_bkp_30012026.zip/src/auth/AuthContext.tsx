import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { getMe, type UserRole } from "@/api/authApi";

export type AuthUser = {
  id: string;
  name?: string;
  role: UserRole;
  modules?: string[];
};

type AuthState = {
  user: AuthUser | null;
  loading: boolean;
  error: string | null;
  userId: string;
  setUserId: (id: string) => void;
  refresh: () => Promise<void>;
};

const AuthCtx = createContext<AuthState | null>(null);

function getStoredUserId() {
  const v = localStorage.getItem("userId");
  return (v && v.trim()) || "admin1"; // valeur de dev (peut être modifiée via l'UI)
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [userId, _setUserId] = useState<string>(() => getStoredUserId());
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const setUserId = useCallback((id: string) => {
    const next = (id || "").trim();
    localStorage.setItem("userId", next);
    _setUserId(next);
  }, []);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // http.ts injecte X-User-Id depuis localStorage
      const me = await getMe();
      setUser(me.user as AuthUser);
    } catch (e: any) {
      setUser(null);
      setError(e?.message ?? "Impossible de charger l'utilisateur");
    } finally {
      setLoading(false);
    }
  }, []);

  // si userId change, on refresh
  useEffect(() => {
    refresh();
  }, [userId, refresh]);

  const value = useMemo<AuthState>(
    () => ({ user, loading, error, userId, setUserId, refresh }),
    [user, loading, error, userId, setUserId, refresh]
  );

  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthCtx);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
