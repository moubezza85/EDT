import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "./AuthContext";
import type { UserRole } from "@/api/authApi";

function defaultFallback(role: UserRole) {
  if (role === "formateur") return "/virtuel";
  return "/";
}

export default function RequireRole({
  roles,
  children,
  fallbackPath,
}: {
  roles: UserRole[];
  children: React.ReactNode;
  fallbackPath?: string;
}) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="p-6 text-sm text-gray-600">Chargement…</div>
    );
  }

  if (!user) {
    // pas d'utilisateur => rester sur layout, l'UI permet de renseigner userId
    return <div className="p-6 text-sm text-red-600">Utilisateur introuvable.</div>;
  }

  if (!roles.includes(user.role)) {
    return <Navigate to={fallbackPath ?? defaultFallback(user.role)} replace />;
  }

  return <>{children}</>;
}
