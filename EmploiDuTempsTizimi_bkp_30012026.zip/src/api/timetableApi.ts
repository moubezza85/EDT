// src/api/timetableApi.ts
import { httpOk } from "./http";
import type { Session } from "../types";

export type AddSessionInput = {
  formateur: string;
  groupe: string;
  module: string;
  jour: string;
  creneau: number;
  salle: string;
};

export type AddSessionResponse = {
  ok: true;
  version: number;
  session: Session;
};

export function addSession(input: AddSessionInput) {
  return httpOk<AddSessionResponse>("/api/timetable/sessions", {
    method: "POST",
    body: JSON.stringify(input),
  });
}


export const TEAMS_ROOM_ID = "TEAMS";

export function isOnlineSession(session: { salle?: string | null }) {
  return (session?.salle ?? "").toUpperCase() === TEAMS_ROOM_ID;
}
