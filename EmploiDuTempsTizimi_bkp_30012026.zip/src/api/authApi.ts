// src/api/authApi.ts
import { http } from "./http";

export type UserRole = "admin" | "surveillant" | "formateur";

export type MeResponse = {
  ok: boolean;
  user: {
    id: string;
    name?: string;
    role: UserRole;
    modules?: string[];
  };
};

export async function getMe() {
  return await http<MeResponse>("/api/auth/me");
}
